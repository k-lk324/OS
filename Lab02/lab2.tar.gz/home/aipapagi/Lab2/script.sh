#!/bin/bash
date
current_time=$(date +%s)
echo "Current time: $current_time"
echo "Current time * 2: $((current_time * 2))"

for i in {1..20}
do
    echo $i
done
